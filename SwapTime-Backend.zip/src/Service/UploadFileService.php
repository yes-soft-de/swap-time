<?php


namespace App\Service;


use Gedmo\Sluggable\Util\Urlizer;
use Symfony\Component\Asset\Context\RequestStackContext;
use Symfony\Component\HttpFoundation\File\UploadedFile;

class UploadFileService
{
    private $uploadPath;
    private $requestStackContext;

    public function __construct(string $uploadPath, RequestStackContext $requestStackContext)
    {
        $this->uploadPath = $uploadPath;
        $this->requestStackContext = $requestStackContext;
    }

    public function uploadImage(UploadedFile $uploadedFile): string
    {
        $destination = $this->getPublicPath();
        dd($destination);

        $ordinalFileName = pathinfo($uploadedFile->getClientOriginalName(),PATHINFO_FILENAME);

        $newFileName = Urlizer::urlize($ordinalFileName).'-'.uniqid().'.'.$uploadedFile->guessExtension();

        $uploadedFile->move($destination, $newFileName);

        return $destination.$newFileName;
    }

    public function getPublicPath(): string
    {
        //first place to look like 'uploads'
        $destination = $this->uploadPath.'/public/';

        $d = $this->requestStackContext->getBasePath();
        //main folder that hold images
        return $d;
    }
}